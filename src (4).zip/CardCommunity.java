
public class CardCommunity extends Card {
	int number;
	String description;
	public CardCommunity(int number,String description){
		this.number = number;
		this.description = description;
	}
	public int getNumber(){
		return number;
	}
	
	public void setNumber(int number){
		this.number = number;
	}
	
	

	public String doAction(Player p, SquaresInfo board){
		if(number == 1){
			p.addMoney(25);
			return "Player received Consultany Fee and won 25$.";
		}else if(number ==2){
			p.addCard(this);
			return "Player won Bargain Business Card: When you land on an unowned propert you want, buy it for only $100.";
		}else if(number ==3){
			p.addCard(this);
			return "Player won Renovation Success Card: Collect $50 extra rent from the next player who lands on any of your properties.";
		}
		return type;	// For error handling
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
