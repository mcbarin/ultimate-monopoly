
public class CardChance extends Card {
	int number;
	String description;
	
	/*
 	1-    Advance to St. Charles Place
	2-    Advance to Squeeze Play, if you pass �Go�, collect $200 from the bank.
	3-    You are elected as the Chairperson. Pay each player $50.
	4-    Advance to �Go�, collect $200.
	  */
	
	public CardChance(int number,String description){
		this.number = number;
		this.description = description;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}
	
	// This should return string.
	public String doAction(Player p, SquaresInfo board){
		if(number == 1){
			p.setPosition(6);
			return "Player Advanced to St. Charles Place";
			
		}else if(number == 2){ // SHOULD RUN THE PLAYERARRIVED METHOD AGAIN
			if(p.getPosition()>15){
				p.setPosition(15);
				p.addMoney(200);
				return "Player Advanced to Squeeze Play Square and won 200$ for passing GO Square.";
			}
			else{
				p.setPosition(15);
				return "Player Advanced to Squeeze Play Square.";
			}
		}else if(number ==3){
			// Player pays each active player 50 $.
			// CHECK FOR ACTIVE PLAYERS
			//########################
			// IMPORTANT
			//########################
			Player others;
			int numOfPlayers = board.getTotalPlayer()-1;
			int moneyWillBePayed = numOfPlayers*50; // Ask if there is an inactive player or not later.DON'T FORGET.
			if(p.getMoney()<moneyWillBePayed){
				// Asks player to sell properties.
				// CHECK LATER.
				if(p.getValueOfProperties() + p.getMoney() > moneyWillBePayed){
					for (int i = 0; i < numOfPlayers; i++) {
						others = board.getPlayers()[i];
						if (others.getId() != p.getId() && others.getIsPlaying()){
							others.addMoney(50);
							p.substractMoney(50);
					}}
					// Player's money is payed. Player should sell property. Player's money is negative now.
					// So after the sell, player's money should be checked because it should be positive.
					return "HasToSell";
				}
				else {
					p.broke();
					return "Player is broke and out of the game.";
				}
			}
			else {
				for (int i = 0; i < numOfPlayers; i++) {
					others = board.getPlayers()[i];
					if (others.getId() != p.getId() && others.getIsPlaying()){
						others.addMoney(50);
						p.substractMoney(50);
				}}
				return "Player payed 50$ to other players.";
			}
		}else if(number == 4){
			p.setPosition(0);
			p.addMoney(200);
			return "Player Advanced to GO Square and won 200$";
					
		}
		return "Error in CardChance Class."; // Just in case.
	}
	
	
}
