
public class Card {
	public String type = "";
	// For chance card, "chance"; for community chest card, "community".

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
}
