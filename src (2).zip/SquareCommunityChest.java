import java.util.Queue;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

// Same thing with the chance square is valid for community chest square.
// CommunityChestCards should be initialized for first community chest square: id:2


public class SquareCommunityChest extends Square {
	Queue<CardCommunity> deck = new LinkedList<CardCommunity>();
	public SquareCommunityChest(String name) {
		super(name, "SquareCommunityChest", GUI.myWhite);
		// TODO Auto-generated constructor stub
	}

	
	public CardCommunity getCommunityChestCard(){		
			CardCommunity c = deck.poll();
			if(c.getNumber()==1){
				deck.add(c);
			}
			return c;
	}
	
	public void addCommunityChestCard(CardCommunity c){
		deck.add(c);
	}
	
	public void createCommunityChestCards(){
		
		CardCommunity c1 = new CardCommunity(1,"Receive Consultancy Fee: Collect $25 from the bank.");
		CardCommunity c2= new CardCommunity(2," Bargain Business: When you land on an unowned propert you want, buy it for only $100. Keep until needed.");
		CardCommunity c3= new CardCommunity(3,"Renovation Success: Collect $50 extra rent from the next player who lands on any of your properties."); 
		
		deck.add(c1);
		deck.add(c1);
		deck.add(c2);
		deck.add(c2);
		deck.add(c3);
		deck.add(c3);
		Collections.shuffle((List<?>) deck);
		
		
		}
		
	

	

}
