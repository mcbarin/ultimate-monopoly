
public class CardCommunity extends Card {

}
