import java.util.Random;

public class SquareRollOnce extends Square {

	public SquareRollOnce(String name) {
		super(name,"SquareRollOnce",GUI.myWhite);
		// TODO Auto-generated constructor stub
	}

}
