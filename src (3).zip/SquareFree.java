import java.awt.*;


public class SquareFree extends Square {

	public SquareFree(String name, Color color) {
		super(name,"SquareFree", color);
		// TODO Auto-generated constructor stub
	}

	
	

}
